# My-Smart-Buy
Django webapp that scrapes all the required product information like prices ,name, rating , images ,description etc from popular eCommerce websites.The website can be used to compare similar products at different eCommerce stores which will reduce the time given for online shopping.
